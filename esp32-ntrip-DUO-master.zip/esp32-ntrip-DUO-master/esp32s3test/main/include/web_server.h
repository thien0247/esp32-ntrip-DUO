#ifndef ESP32_XBEE_WEB_SERVER_H
#define ESP32_XBEE_WEB_SERVER_H

void web_server_init();

#endif //ESP32_XBEE_WEB_SERVER_H
